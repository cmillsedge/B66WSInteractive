# B66WSInteractive
This is a simple app showing how to use some of the BioRails 6 Web Services interactively.
